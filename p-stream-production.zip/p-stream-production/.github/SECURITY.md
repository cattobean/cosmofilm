# Security Policy

## Supported Versions

The latest version of sudo-flix is the only version that is supported, as it is the only version that is being actively developed.

## Reporting a Vulnerability

You can contact the sudo-flix maintainers to report a vulnerability:
 - Report the vulnerability in the [Discord](https://docs.pstream.org/links/discord).
