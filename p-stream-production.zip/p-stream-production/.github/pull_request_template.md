This pull request resolves #XXX

 - [ ] I have read and agreed to the [code of conduct](https://github.com/p-stream/p-strean/blob/production/.github/CODE_OF_CONDUCT.md).
 - [ ] I have read and complied with the [contributing guidelines](https://github.com/p-stream/p-strean/blob/production/.github/CONTRIBUTING.md).
 - [ ] I have tested all of my changes.
 - Enter discord user: `` (we require this for the contributor role)
