export function SecondaryLabel(props: { children: React.ReactNode }) {
  return <p className="text-type-text">{props.children}</p>;
}
